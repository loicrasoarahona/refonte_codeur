		<footer class="absolute-footer-1">
			<div class="bg-dark-grey color-light-grey">
			<!-- Pied-de-page de la page -->
				<div class="m-auto content p-20-10 txt-align-center">
					Copyright © 2018, <strong><?= ucwords(nom_site); ?></strong> - Tous droits réservés
				</div>
			</div>
		</footer>
        <!-- jQuery -->
     

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="../js/app.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/sb-admin-2.min.js"></script>
  <script src="vendor/chart.js/Chart.min.js"></script>
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>
  <script src="bower_components/wysihtml/parser_rules/advanced_and_extended.js"></script>
       
        <script>
            ClassicEditor
                    .create( document.querySelector( '#editor' ) )
                    .then( editor => {
                            console.log( editor );
                    } )
                    .catch( error => {
                            console.error( error );
                    } );

                    ClassicEditor
                    .create( document.querySelector( '#description' ) )
                    .then( editor => {
                            console.log( editor );
                    } )
                    .catch( error => {
                            console.error( error );
                    } );


                    ClassicEditor
                    .create( document.querySelector( '#Apropos' ) )
                    .then( editor => {
                            console.log( editor );
                    } )
                    .catch( error => {
                            console.error( error );
                    } );

                    ClassicEditor
                    .create( document.querySelector( '#condition' ) )
                    .then( editor => {
                            console.log( editor );
                    } )
                    .catch( error => {
                            console.error( error );
                    } );

                    ClassicEditor
                    .create( document.querySelector( '#nomCoupons' ) )
                    .then( editor => {
                            console.log( editor );
                    } )
                    .catch( error => {
                            console.error( error );
                    } );
        </script>
       <script>

        </script>
   
	</body>
</html>