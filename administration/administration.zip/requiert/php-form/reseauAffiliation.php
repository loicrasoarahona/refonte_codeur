<?php
	if (!empty($_POST['nom'])) { $post_nom = htmlspecialchars(addslashes($_POST['nom'])); } else { $post_nom = null; }
	if (!empty($_POST['url'])) { $post_url = addslashes($_POST['url']); } else { $post_url = null; }
	if (!empty($_POST['description'])) { $post_description = htmlspecialchars(addslashes($_POST['description'])); } else { $post_description = null; }
		
	if (!empty($_POST['submit_add'])) {
	 
		$pdo->exec("INSERT INTO `reseau_affiliation`
        (
        `id`,
        `nom_reseau_affiliation`,
        `url_reseau_affiliation`,
        `description_reseau_affiliation`
        )
        VALUES ('',
          '".$post_nom."',
           '".$post_url."', 
           '".$post_description."'
        )");
		$post_nom = null;
		$post_url = null;
		$post_description = null;
        $reponsConfirm = 'Le reseaux a bien été ajoutée.';
	}

	if (!empty($_POST['submit_upd'])) {
	  
		$sql = "UPDATE reseau_affiliation SET
         nom_reseau_affiliation = '".$post_nom."', 
         url_reseau_affiliation = '".$post_url."',
         description_reseau_affiliation = '".$post_description."' 
         WHERE id = '".intval($_GET['id'])."'";

		$pdo->exec($sql) or die ('Erreur : '.mysql_error());
		
		$reponsConfirm = 'L\'offre a bien été modifiée.';
	}
	
	if (isset($reponsConfirm)) {
?>
		<script type="text/javascript">
			swal({
				text: "<?= $reponsConfirm; ?>",
				button: "Fermer",
				icon: "success",
				closeOnClickOutside: false,
				closeOnEsc: false,
			});
		</script>
<?php
	}
	
	if (isset($reponsError)) {
?>
		<script type="text/javascript">
			swal({
				text: "<?= $reponsError; ?>",
				button: "Fermer",
				icon: "error",
				closeOnClickOutside: false,
				closeOnEsc: false,
			});
		</script>
<?php
	}
?>